const API=import.meta.env.VITE_API_URL||'http://localhost:8000';
export async function context(lat:number,lon:number){const r=await fetch(`${API}/api/v1/field-context?latitude=${lat}&longitude=${lon}`);if(!r.ok)throw Error('context');return r.json()}
export async function advisory(body:unknown){const r=await fetch(`${API}/api/v1/advisory`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(!r.ok)throw Error('advisory');return r.json()}
export async function diagnose(crop:string,file:File){const f=new FormData();f.append('crop',crop);f.append('image',file);const r=await fetch(`${API}/api/v1/disease/diagnose`,{method:'POST',body:f});if(!r.ok)throw Error('diagnosis');return r.json()}
