# Architecture

Farmer/mobile/web UI → FastAPI → decision services + interoperability layer → weather/Earth-observation/model providers.

The canonical `brics-agrinet-1.0` observation makes country-specific records portable. Provider interfaces isolate national data sources from application logic.

Production additions: PostgreSQL/PostGIS, object storage, OIDC/RBAC, consent/audit logs, national weather APIs, Sentinel/Landsat integrations, validated regional disease models, multilingual SMS/IVR, event streaming and model monitoring.
