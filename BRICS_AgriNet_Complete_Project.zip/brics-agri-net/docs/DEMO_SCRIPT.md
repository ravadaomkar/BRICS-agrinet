# Demo
1. Open the dashboard.
2. Show NDVI, moisture, rainfall and NDMI.
3. Refresh the explainable advisory.
4. Open Disease scan and upload a leaf image.
5. Show the interoperability endpoint at `/docs`.
6. Explain how country adapters normalize partner records into one canonical contract.
