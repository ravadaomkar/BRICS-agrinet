# BRICS AgriNet — Interoperable Digital Agriculture Network

A runnable full-stack MVP based on the supplied BRICS Cooperation challenge: localized agro-advisories using soil, weather and Earth-observation data; crop-disease screening; and a country-neutral interoperability layer for cross-border agricultural data exchange.

## Features
- FastAPI REST backend with Swagger/OpenAPI.
- React + TypeScript dashboard.
- Soil + weather + satellite-inspired advisory engine with explainable evidence.
- Leaf-image disease screening baseline that works offline; replaceable with a validated ML model.
- Canonical `brics-agrinet-1.0` observation schema.
- Country adapters for India, Brazil, South Africa, China and Russia, plus generic fallback.
- Docker Compose deployment.
- Tests and sample data.

## Run
### Docker
```bash
cp .env.example .env
docker compose up --build
```
Frontend: http://localhost:5173  | API: http://localhost:8000 | Docs: http://localhost:8000/docs

### Local
Backend:
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
Frontend:
```bash
cd frontend
npm install
npm run dev
```

## Demo API
`POST /api/v1/advisory` accepts farmer, location, crop, soil, weather and satellite observations and returns prioritized actions, risk and irrigation guidance.

`POST /api/v1/disease/diagnose` accepts multipart `crop` + `image` and returns a screening result.

`POST /api/v1/interoperability/normalize` maps partner-country records into the canonical schema.

## Production roadmap
Replace demo weather/satellite providers with official national or commercial feeds; train and validate regional crop-disease models; add PostgreSQL/PostGIS, object storage, OIDC/RBAC, consent/audit logging, multilingual SMS/IVR, event streaming and model monitoring.

This is decision-support software, not a substitute for local agronomists or regulated pesticide/fertilizer instructions.
