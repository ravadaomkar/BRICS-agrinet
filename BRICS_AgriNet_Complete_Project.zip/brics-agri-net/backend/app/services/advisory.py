from uuid import uuid4
from app.models.agriculture import AdvisoryRequest, AdvisoryResponse, Action

def build_advisory(r: AdvisoryRequest) -> AdvisoryResponse:
    a=[]; stress=0
    if r.satellite.ndvi < .40: stress+=2; a.append(Action(priority="high",title="Scout stressed zones",action="Inspect low-vigor areas for pests, disease, nutrient deficiency or water stress.",reason="Vegetation vigor is low.",evidence=[f"NDVI {r.satellite.ndvi:.2f}"]))
    elif r.satellite.ndvi < .55: stress+=1; a.append(Action(priority="medium",title="Targeted scouting",action="Walk representative zones and compare plant vigor with healthy areas.",reason="Vegetation vigor is below the demo reference band.",evidence=[f"NDVI {r.satellite.ndvi:.2f}"]))
    if r.soil.moisture_pct < 25 and r.weather.rainfall_next_72h_mm < 15:
        stress+=1; a.append(Action(priority="high",title="Irrigation check",action="Inspect the field and consider measured irrigation if plants show water stress.",reason="Low soil moisture with limited forecast rain.",evidence=[f"Moisture {r.soil.moisture_pct:.0f}%",f"Rain {r.weather.rainfall_next_72h_mm:.0f} mm"]))
    elif r.weather.rainfall_next_72h_mm >= 35:
        a.append(Action(priority="medium",title="Delay routine irrigation",action="Avoid routine irrigation until the rainfall window passes and re-check soil moisture.",reason="Meaningful rainfall is forecast.",evidence=[f"72h rain {r.weather.rainfall_next_72h_mm:.0f} mm"]))
    if r.soil.ph < 5.5 or r.soil.ph > 8:
        stress+=1; a.append(Action(priority="medium",title="Review soil pH",action="Confirm pH with a calibrated test before applying amendments.",reason="pH is outside a broad general range.",evidence=[f"pH {r.soil.ph:.1f}"]))
    if r.soil.nitrogen_kg_ha < 50:
        a.append(Action(priority="medium",title="Review nitrogen status",action="Use a current soil test and crop-specific recommendation before applying nitrogen.",reason="Measured nitrogen is relatively low for this demo rule set.",evidence=[f"N {r.soil.nitrogen_kg_ha:.0f} kg/ha"]))
    if r.weather.wind_kmh >= 30:
        a.append(Action(priority="medium",title="Weather caution",action="Avoid non-essential field operations during strong winds.",reason="Forecast wind is elevated.",evidence=[f"Wind {r.weather.wind_kmh:.0f} km/h"]))
    if not a:
        a.append(Action(priority="low",title="Continue routine monitoring",action="Maintain normal scouting and re-check soil, weather and satellite indicators.",reason="No major trigger was detected.",evidence=[f"NDVI {r.satellite.ndvi:.2f}",f"Moisture {r.soil.moisture_pct:.0f}%"]))
    risk="high" if stress>=4 else "moderate" if stress>=2 else "low"
    return AdvisoryResponse(advisory_id="ADV-"+uuid4().hex[:10].upper(),farmer_id=r.farmer_id,crop=r.crop,risk_level=risk,summary=f"{risk.title()} crop-risk level detected from submitted field observations.",actions=a,irrigation={"recommendation":"hold" if r.weather.rainfall_next_72h_mm>=35 else "inspect","rainfall_next_72h_mm":r.weather.rainfall_next_72h_mm,"soil_moisture_pct":r.soil.moisture_pct},data_quality={"weather":True,"soil":True,"satellite":True,"cloud_cover_pct":r.satellite.cloud_cover_pct},model_version="rule-engine-1.0")
