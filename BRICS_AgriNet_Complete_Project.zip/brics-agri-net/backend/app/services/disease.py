from io import BytesIO
from PIL import Image
import numpy as np
class DiseaseService:
    def diagnose(self,data,crop):
        x=np.asarray(Image.open(BytesIO(data)).convert("RGB").resize((224,224))).astype(float)/255
        r,g,b=x[...,0],x[...,1],x[...,2]; yellow=((r>.55)&(g>.45)&(b<.35)).mean(); dark=((r<.28)&(g<.28)&(b<.28)).mean(); green=((g>r*1.08)&(g>b*1.08)).mean()
        if yellow>.16: label,conf,next_step="possible nutrient stress / chlorosis",min(.9,.55+yellow),"Inspect representative leaves and confirm with local agronomy or a validated model."
        elif dark>.08: label,conf,next_step="possible leaf-spot or necrotic symptoms",min(.86,.50+dark),"Check lesion pattern on multiple leaves before treatment decisions."
        elif green<.35: label,conf,next_step="possible general plant stress",.58,"Check irrigation, root-zone conditions, pests and nutrients."
        else: label,conf,next_step="no strong symptom pattern detected",.62,"Continue scouting; a clean image does not rule out early disease."
        return {"crop":crop,"label":label,"confidence":round(float(conf),2),"screening_only":True,"next_step":next_step}
