from datetime import datetime, timezone
def weather(lat,lon):
    return {"provider":"demo-weather","observed_at":datetime.now(timezone.utc).isoformat(),"temperature_c":28,"humidity_pct":72,"rainfall_next_72h_mm":11,"wind_kmh":14,"location":{"latitude":lat,"longitude":lon}}
def satellite(lat,lon):
    return {"provider":"demo-earth-observation","observed_at":datetime.now(timezone.utc).isoformat(),"ndvi":.63,"ndmi":.42,"cloud_cover_pct":18,"location":{"latitude":lat,"longitude":lon}}
