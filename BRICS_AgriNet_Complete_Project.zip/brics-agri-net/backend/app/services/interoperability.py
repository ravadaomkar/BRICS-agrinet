from datetime import datetime, timezone
from app.schemas.interoperability import CanonicalObservation
class Registry:
    adapters={"IN":"IndiaAgriAdapter","BR":"BrazilAgriAdapter","ZA":"SouthAfricaAgriAdapter","CN":"ChinaAgriAdapter","RU":"RussiaAgriAdapter"}
    def normalize(self,country,p):
        code=country.upper(); adapter=self.adapters.get(code,"GenericAgriAdapter"); warnings=[]
        farmer=str(p.get("farmer_id") or p.get("farmerId") or "UNKNOWN"); crop=str(p.get("crop") or p.get("crop_type") or "unknown")
        loc=p.get("location") or {"latitude":p.get("lat",0),"longitude":p.get("lon",0)}
        values=p.get("values") if isinstance(p.get("values"),dict) else {k:v for k,v in p.items() if k not in {"farmer_id","farmerId","crop","crop_type","location","lat","lon","observed_at","timestamp"}}
        if not loc.get("latitude") and not loc.get("longitude"): warnings.append("Location not supplied; use authoritative field coordinates.")
        c=CanonicalObservation(source_country=code,farmer_id=farmer,location=loc,crop=crop,observation_type=str(p.get("observation_type") or "field_observation"),observed_at=str(p.get("observed_at") or p.get("timestamp") or datetime.now(timezone.utc).isoformat()),values=values,provenance={"adapter":adapter,"source_schema":f"{code.lower()}-partner-record-v1"})
        return c,adapter,warnings
