from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.api.routes import router
app=FastAPI(title="BRICS AgriNet API",version="1.0.0",description="Interoperable digital agriculture advisory network")
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_origin_list,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.include_router(router)
@app.get("/")
def root(): return {"name":"BRICS AgriNet","docs":"/docs"}
