from fastapi import APIRouter, UploadFile, File, HTTPException
from app.models.agriculture import AdvisoryRequest
from app.schemas.interoperability import NormalizeRequest, NormalizeResponse
from app.services.advisory import build_advisory
from app.services.disease import DiseaseService
from app.services.providers import weather,satellite
from app.services.interoperability import Registry
router=APIRouter(prefix="/api/v1"); disease=DiseaseService(); registry=Registry()
@router.get("/health")
def health(): return {"status":"ok","service":"brics-agrinet","version":"1.0.0"}
@router.get("/field-context")
def context(latitude:float,longitude:float): return {"weather":weather(latitude,longitude),"satellite":satellite(latitude,longitude)}
@router.post("/advisory")
def advisory(req:AdvisoryRequest): return build_advisory(req)
@router.post("/disease/diagnose")
async def diagnose(crop:str,image:UploadFile=File(...)):
    if image.content_type not in {"image/jpeg","image/png","image/webp"}: raise HTTPException(415,"Use JPEG, PNG or WebP")
    data=await image.read()
    if len(data)>8*1024*1024: raise HTTPException(413,"Image must be <=8 MB")
    return disease.diagnose(data,crop)
@router.get("/interoperability/schema")
def schema(): return {"schema_version":"brics-agrinet-1.0","required":["source_country","farmer_id","location","crop","observation_type","observed_at","values"]}
@router.post("/interoperability/normalize",response_model=NormalizeResponse)
def normalize(req:NormalizeRequest):
    c,a,w=registry.normalize(req.country,req.payload); return NormalizeResponse(canonical=c,adapter=a,warnings=w)
