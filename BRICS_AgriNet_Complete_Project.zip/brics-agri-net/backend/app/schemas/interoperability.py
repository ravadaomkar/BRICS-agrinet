from pydantic import BaseModel, Field
from typing import Any
class CanonicalObservation(BaseModel):
    schema_version: str = "brics-agrinet-1.0"
    source_country: str
    farmer_id: str
    location: dict
    crop: str
    observation_type: str
    observed_at: str
    values: dict[str, Any]
    provenance: dict[str, Any] = Field(default_factory=dict)
class NormalizeRequest(BaseModel):
    country: str
    payload: dict[str, Any]
class NormalizeResponse(BaseModel):
    canonical: CanonicalObservation
    adapter: str
    warnings: list[str] = []
