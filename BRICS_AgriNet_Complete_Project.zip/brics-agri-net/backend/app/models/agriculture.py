from pydantic import BaseModel, Field
class Location(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
class Soil(BaseModel):
    ph: float = Field(ge=0, le=14)
    nitrogen_kg_ha: float = Field(ge=0)
    phosphorus_kg_ha: float = Field(ge=0)
    potassium_kg_ha: float = Field(ge=0)
    moisture_pct: float = Field(ge=0, le=100)
class Weather(BaseModel):
    temperature_c: float
    humidity_pct: float = Field(ge=0, le=100)
    rainfall_next_72h_mm: float = Field(ge=0)
    wind_kmh: float = Field(ge=0)
class Satellite(BaseModel):
    ndvi: float = Field(ge=-1, le=1)
    ndmi: float = Field(ge=-1, le=1)
    cloud_cover_pct: float = Field(ge=0, le=100)
class AdvisoryRequest(BaseModel):
    farmer_id: str
    country: str
    location: Location
    crop: str
    growth_stage: str
    soil: Soil
    weather: Weather
    satellite: Satellite
class Action(BaseModel):
    priority: str
    title: str
    action: str
    reason: str
    evidence: list[str]
class AdvisoryResponse(BaseModel):
    advisory_id: str
    farmer_id: str
    crop: str
    risk_level: str
    summary: str
    actions: list[Action]
    irrigation: dict
    data_quality: dict
    model_version: str
