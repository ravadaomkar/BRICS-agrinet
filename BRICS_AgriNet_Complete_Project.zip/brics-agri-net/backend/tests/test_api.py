from fastapi.testclient import TestClient
from app.main import app
c=TestClient(app)
def test_health(): assert c.get('/api/v1/health').json()['status']=='ok'
def test_normalize():
 r=c.post('/api/v1/interoperability/normalize',json={'country':'IN','payload':{'farmerId':'F1','crop_type':'rice','lat':17.3,'lon':78.4}})
 assert r.status_code==200 and r.json()['canonical']['farmer_id']=='F1'
